import Navbar from './component/Navbar';
import Blog from './component/Blog';
import Services from './component/Services';
import Contact from './component/Contact';
import About from  './component/About';
import Team from './component/Team';
import Home from './component/Home';
import { Route,Routes } from 'react-router-dom';

function App() {
  return (
    <>
    <Navbar/>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/blog" element={<Blog/>}/>
      <Route path="/contact" element={<Contact/>}/>
      <Route path="/services" element={<Services/>}/>
      <Route path="/team" element={<Team/>}/>
      <Route path="/about" element={<About/>}/>
    </Routes>
    </>
  );
}

export default App;
