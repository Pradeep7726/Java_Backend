package com.infinite.Assessment7.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.Assessment7.model.Municipal;
import com.infinite.Assessment7.model.MunicipalInfo;
import com.infinite.Assessment7.repository.MunicipalDaoImpl;

@Service
public class MunicipalServiceImpl implements IMunicipalService {
	@Autowired
	MunicipalDaoImpl cdao;

	@Override
	@Transactional
	public List<MunicipalInfo> getAllComplains() {
		// TODO Auto-generated method stub
		return cdao.getAllComplains();
	}

	@Override
	@Transactional
	public MunicipalInfo getMunicipal(int id) {
		// TODO Auto-generated method stub
		return cdao.getMunicipal(id);
	}

	@Override
	@Transactional
	public MunicipalInfo addMunicipal(MunicipalInfo municipalinfo) {
		// TODO Auto-generated method stub
		return cdao.addMunicipal(municipalinfo);
	}

	@Override
	@Transactional
	public void updateMunicipal(MunicipalInfo municipalinfo) {
		// TODO Auto-generated method stub
		cdao.updateMunicipal(municipalinfo);
		
	}

	@Override
	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		cdao.deleteMunicipal(id);
	}
	/*@Override
	public Municipal findByUsername(String UserName) {
		// TODO Auto-generated method stub
		return cdao.findByUsername(UserName);
	}
	public Municipal save(Municipal municipal) {
		return cdao.save(municipal);		
	}
*/
}
