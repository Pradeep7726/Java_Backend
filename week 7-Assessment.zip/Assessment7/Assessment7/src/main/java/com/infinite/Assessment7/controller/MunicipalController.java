package com.infinite.Assessment7.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.Assessment7.model.Municipal;
import com.infinite.Assessment7.model.MunicipalInfo;
import com.infinite.Assessment7.service.MunicipalServiceImpl;

@Controller
public class MunicipalController {
	@Autowired
	MunicipalServiceImpl cservice;
	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET, headers =
	 * "Accept=application/json") public String goToHomePage() { return
	 * "redirect:/getAllMunicipal"; }
	 * 
	 * @RequestMapping(value = "/getAllMunicipal", method = RequestMethod.GET)
	 * public String getAllCustomers(Model model) {
	 * model.addAttribute("Municipal", new Municipal());
	 * //model.addAttribute("listOfCustomers", cservice.getAllCustomers());
	 * return "municipaldetails"; }
	 */

	@RequestMapping(value = "/", method = RequestMethod.GET, headers = "Accept=application/json")
	public String goToHomePage() {
		return "redirect:/getAllComplains";
	}

	@RequestMapping(value = "/getAllComplains", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getAllComplains(Model m) {
		m.addAttribute("MunicipalInfo", new MunicipalInfo());
		m.addAttribute("listOfComplains", cservice.getAllComplains());
		return "complaindetails";
	}

	@RequestMapping(value = "/addComplains", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addComplains(@ModelAttribute("MunicipalInfo") MunicipalInfo municipalinfo) {
		if (municipalinfo.getId() == 0) {
			cservice.addMunicipal(municipalinfo);
		} else {
			cservice.updateMunicipal(municipalinfo);
			;
		}
		return "redirect:/getAllComplains";
	}

	@RequestMapping(value = "/updateComplains/{id}")
	public String updateComplains(@PathVariable("id") int id, Model model) {
		model.addAttribute("MunicipalInfo", this.cservice.getMunicipal(id));
		model.addAttribute("listOfComplains", this.cservice.getAllComplains());
		return "complaindetails";
	}

	@RequestMapping(value = "/deleteComplains/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteComplains(@PathVariable("id") int id) {
		cservice.deleteMunicipal(id);
		;
		return "redirect:/getAllComplains";
	}
}
