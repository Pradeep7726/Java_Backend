package com.infinite.springbootmvc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.springbootmvc.model.Municipal;
import com.infinite.springbootmvc.service.CustomerServiceImpl;

@Controller
public class CustomerController {
	private static final Logger logger = Logger.getLogger(CustomerController.class);
	@Autowired
	CustomerServiceImpl customerServiceImpl;

		@RequestMapping(value = "/", method = RequestMethod.GET, headers = "Accept=application/json")
		public String goToHomePage() {
			return "redirect:/getAllComplains";
		}
		@RequestMapping(value = "/getAllComplains", method = RequestMethod.GET, headers = "Accept=application/json")
		public String getAllComplains(Model m) {
			m.addAttribute("municipal",new Municipal());
			m.addAttribute("listOfComplains",  customerServiceImpl.getAllComplains());
			return "complaindetails";
		}
		@RequestMapping(value = "/addComplains", method = RequestMethod.POST, headers = "Accept=application/json")
		public String addComplains(@ModelAttribute("municipal") Municipal municipal) {
			if (municipal.getId() == 0) {
				 customerServiceImpl.addMunicipal(municipal);
			} else {
				 customerServiceImpl.updateMunicipal(municipal);
			}
			return "redirect:/getAllComplains";
		}
		@RequestMapping(value = "/updateComplains/{id}")
		public String updateComplains(@PathVariable("id") int id, Model model) {
			model.addAttribute("municipal", this. customerServiceImpl.getMunicipal(id));
			model.addAttribute("listOfComplains", this. customerServiceImpl.getAllComplains());
			return "complaindetails";
		}
		@RequestMapping(value = "/deleteComplains/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
		public String deleteComplains(@PathVariable("id") int id) {
			 customerServiceImpl.deleteMunicipal(id);;
			return "redirect:/getAllComplains";
		}
	}