package com.infinite.springbootmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.springbootmvc.model.Municipal;
import com.infinite.springbootmvc.repository.CustomerDaoImpl;

@Service
public class CustomerServiceImpl implements ICustomerService{


	@Autowired
	CustomerDaoImpl customerDaoImpl;

	@Override
	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub

		return customerDaoImpl.getAllComplains();
	}
	@Override
	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return customerDaoImpl.getMunicipal(id);
	}
	@Override
	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return customerDaoImpl.addMunicipal(municipal);
	}
	@Override
	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		customerDaoImpl.updateMunicipal(municipal);
	}
	@Override
	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		customerDaoImpl.deleteMunicipal(id);
	}
}