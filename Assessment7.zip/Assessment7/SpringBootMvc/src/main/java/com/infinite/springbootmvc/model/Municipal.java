package com.infinite.springbootmvc.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Municipal")
public class Municipal {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "name")
	private String name;
	@Column(name = "date")
	private String date;
	@Column(name = "address")
	private String address;

	@Column(name = "mobileno")
	private String mobileno;

	@Column(name = "email")
	private String email;

	@Column(name = "complains")
	private String complains;

	@Column(name = "wardno")
	private String wardno;
	

	public Municipal() {
		//super();
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getMobileno() {
		return mobileno;
	}


	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getComplains() {
		return complains;
	}


	public void setComplains(String complains) {
		this.complains = complains;
	}


	public String getWardno() {
		return wardno;
	}


	public void setWardno(String wardno) {
		this.wardno = wardno;
	}
	
}

