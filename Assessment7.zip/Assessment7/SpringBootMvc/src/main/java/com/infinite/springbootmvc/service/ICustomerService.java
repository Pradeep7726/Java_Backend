package com.infinite.springbootmvc.service;

import java.util.List;

import com.infinite.springbootmvc.model.Municipal;

public interface ICustomerService {
	public List<Municipal> getAllComplains();//to display list of all Complains
	public Municipal getMunicipal(int id);//to get the details by id
	public Municipal addMunicipal(Municipal municipal);// inserting details
	public void updateMunicipal(Municipal municipal);//updating the details
	public void deleteMunicipal(int id);//deleting the details by id

}